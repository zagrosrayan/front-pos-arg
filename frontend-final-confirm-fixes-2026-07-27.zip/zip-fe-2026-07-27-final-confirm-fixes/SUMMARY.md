# Frontend fixes - final confirmation / invoice / summary
- Hide reprint after final confirmation
- Move discount UI to pre-invoice; remove from complete modal
- Disable cash/POS when resident guest selected
- Fix room search params
- Fix CheckoutPrice discount row (0 && bug showing bare 0)
- Fix invoice toPersianDigits / hydration / clipboard
