export { default } from './SettingPage'
