export { default } from './NextPurchaseDiscountTable'
