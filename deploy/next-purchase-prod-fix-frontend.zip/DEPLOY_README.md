# Frontend deploy note

No frontend file changes in this release.

Backend-only fix (SMS field order + next-purchase complete capacity).
Existing frontend on server (SMS toggle / checkout) is already sufficient.

If checkout still hides next-purchase codes after backend deploy, hard-refresh the browser (Ctrl+F5).
