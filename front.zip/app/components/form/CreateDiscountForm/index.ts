export { default } from './CreateDiscountForm'
