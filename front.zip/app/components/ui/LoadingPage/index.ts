export { default } from './LoadingPage'
