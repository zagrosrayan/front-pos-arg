export { default } from './PrinterTable'
