export { default } from './ResidentCustomerReportTable'
