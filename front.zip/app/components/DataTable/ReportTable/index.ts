export { default } from './ReportTable'
