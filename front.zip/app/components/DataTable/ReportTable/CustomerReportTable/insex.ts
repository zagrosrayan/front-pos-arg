export { default } from './CustomerReportTable'
