export { default } from './GlobalDiscountReportTable'
