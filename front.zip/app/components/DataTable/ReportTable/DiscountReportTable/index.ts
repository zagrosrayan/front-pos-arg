export { default } from './DiscountReportTable'
