export { default } from './CustomerTable'
