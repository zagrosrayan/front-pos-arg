export { default } from './GlobalDiscountTable'
