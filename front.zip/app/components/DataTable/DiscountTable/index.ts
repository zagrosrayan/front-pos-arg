export { default } from './DiscountTable'
