export { default } from './LogTable'
