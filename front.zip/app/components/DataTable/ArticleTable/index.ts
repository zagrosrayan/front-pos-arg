export { default } from './ArticleTable'
