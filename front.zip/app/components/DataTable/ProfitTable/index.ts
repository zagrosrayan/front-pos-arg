export { default } from './ProfitTable'
