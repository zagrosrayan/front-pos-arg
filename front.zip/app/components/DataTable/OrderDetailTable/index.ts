export { default } from './OrderDetailTable'
