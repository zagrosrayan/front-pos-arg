export { default } from './FoodReportTable'
